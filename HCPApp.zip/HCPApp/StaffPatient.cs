﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class StaffPatient : Form
    {
        private Functions Con;
        private string staffMemberName;
        public StaffPatient(string staffMemberName)
        {
            InitializeComponent();
            Con = new Functions();
            this.staffMemberName = staffMemberName;
            ShowPatient();
        }

        private void ShowPatient()
        {
            try
            {
                string Query = "Select * from PatientTbl";
                PatientList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void GoBackToStaffDashboard()
        {
            this.Close();
            StaffDashboard staffDashboard = new StaffDashboard(staffMemberName);
            staffDashboard.Show();
        }
        private void PatientList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StaffPatient staffpatient = new StaffPatient(staffMemberName);
            staffpatient.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            StaffDoctor staffdoctor = new StaffDoctor(staffMemberName);
            staffdoctor.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            StaffAppointment staffappointment = new StaffAppointment(staffMemberName);
            staffappointment.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            GoBackToStaffDashboard();
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (FirstName.Text == "" || LastName.Text == "" || GenderCombo.SelectedIndex == -1 || BGCombo.SelectedIndex == -1 || Contact.Text == "" || MedHistory.Text == "" || Alergies.Text == "")
                {
                    MessageBox.Show("Missing Some of Some or All of The data!");
                }
                else
                {
                    string FName = FirstName.Text;
                    string LName = LastName.Text;
                    string Gender = GenderCombo.SelectedItem.ToString();
                    string BloodGroup = BGCombo.SelectedItem.ToString();
                    string PatientContact = Contact.Text;
                    string MedicalHistory = MedHistory.Text;
                    string Allergies = Alergies.Text;

                    string Query = "INSERT INTO PatientTbl (FirstName, LastName, DoB, Gender, BloodGroup, PatientContact, MedicalHistory, Allergies) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')";
                    Query = string.Format(Query, FName, LName, DoBPicker.Value.Date.ToString("yyyy-MM-dd"), Gender, BloodGroup, PatientContact, MedicalHistory, Allergies); // Format the date correctly
                    Con.SetData(Query);
                    ShowPatient();
                    MessageBox.Show("Patient Added.");
                    FirstName.Text = "";
                    LastName.Text = "";
                    DoBPicker.Value = DateTime.Now.Date;
                    GenderCombo.SelectedIndex = -1;
                    BGCombo.SelectedIndex = -1;
                    Contact.Text = "";
                    MedHistory.Text = "";
                    Alergies.Text = "";
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
                MessageBox.Show("You Don't have permission to Update data");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SORRY! You Don't have permission to Delete Data");
        }
    }
}
