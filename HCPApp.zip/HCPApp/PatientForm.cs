﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Drawing.Printing;

namespace HCPApp
{
    public partial class PatientForm : Form
    {
        Functions Con;

        public PatientForm()
        {
            InitializeComponent();
            Con = new Functions();
            ShowDiagnosis();
            ShowPatient();

        }

        private void ShowDiagnosis()
        {
            try
            {
                string Query = "Select * from DiagnosisTbl";
                DiagnosisList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void ShowPatient()
        {
            try
            {
                string Query = "Select * from PatientTbl";
                PatientList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (FirstName.Text == "" || LastName.Text == "" || GenderCombo.SelectedIndex == -1 || BGCombo.SelectedIndex == -1 || Contact.Text == "" || MedHistory.Text == "" || Alergies.Text == "")
                {
                    MessageBox.Show("Missing Some of Some or All of The data!");
                }
                else
                {
                    string FName = FirstName.Text;
                    string LName = LastName.Text;
                    string Gender = GenderCombo.SelectedItem.ToString();
                    string BloodGroup = BGCombo.SelectedItem.ToString();
                    string PatientContact = Contact.Text;
                    string MedicalHistory = MedHistory.Text;
                    string Allergies = Alergies.Text;

                    string Query = "INSERT INTO PatientTbl (FirstName, LastName, DoB, Gender, BloodGroup, PatientContact, MedicalHistory, Allergies) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')";
                    Query = string.Format(Query, FName, LName, DoBPicker.Value.Date.ToString("yyyy-MM-dd"), Gender, BloodGroup, PatientContact, MedicalHistory, Allergies); // Format the date correctly
                    Con.SetData(Query);
                    ShowPatient();
                    MessageBox.Show("Patient Added.");
                    FirstName.Text = "";
                    LastName.Text = "";
                    DoBPicker.Value = DateTime.Now.Date; 
                    GenderCombo.SelectedIndex = -1;
                    BGCombo.SelectedIndex = -1;
                    Contact.Text = "";
                    MedHistory.Text = "";
                    Alergies.Text = "";
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (FirstName.Text == "" || LastName.Text == "" || DoBPicker.Value == null || GenderCombo.SelectedIndex == -1 || BGCombo.SelectedIndex == -1 || Contact.Text == "" || MedHistory.Text == "" || Alergies.Text == "")
                {
                    MessageBox.Show("Missing Some or All of the Data!");
                }
                else
                {
                    int patientId = Convert.ToInt32(btnUpdate.Tag);

                    string connectionString = @"Data Source=LAPTOP-A9K7TF0H\SQLEXPRESS;Initial Catalog=HCPAppDB;Integrated Security=True";

                    int rowsAffected = Con.UpdatePatientInfo(patientId, FirstName.Text, LastName.Text, DoBPicker.Value, GenderCombo.SelectedItem.ToString(), BGCombo.SelectedItem.ToString(), Contact.Text, MedHistory.Text, Alergies.Text, connectionString);

                    if (rowsAffected > 0)
                    {
                        ShowPatient();
                        MessageBox.Show("Patient Updated.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update patient information.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to delete this Patient?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int patientId = Convert.ToInt32(btnUpdate.Tag);

                    string connectionString = @"Data Source=LAPTOP-A9K7TF0H\SQLEXPRESS;Initial Catalog=HCPAppDB;Integrated Security=True";

                    int rowsAffected = Con.DeletePatient(patientId, connectionString);

                    if (rowsAffected > 0)
                    {
                        ShowPatient();
                        MessageBox.Show("Patient Deleted.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete doctor.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }

        private void PatientList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = PatientList.Rows[e.RowIndex];
                FirstName.Text = selectedRow.Cells[1].Value.ToString();
                LastName.Text = selectedRow.Cells[2].Value.ToString();
                DoBPicker.Value = (DateTime)selectedRow.Cells[3].Value;
                GenderCombo.SelectedItem = selectedRow.Cells[4].Value.ToString();
                BGCombo.SelectedItem = selectedRow.Cells[5].Value.ToString();
                Contact.Text = selectedRow.Cells[6].Value.ToString();
                MedHistory.Text = selectedRow.Cells[7].Value.ToString();
                Alergies.Text = selectedRow.Cells[8].Value.ToString();
                PatNamelbl.Text = selectedRow.Cells[1].Value.ToString() + " " + selectedRow.Cells[2].Value.ToString();
                PatDoBlbl.Text = ((DateTime)selectedRow.Cells[3].Value).ToString("yyyy-MM-dd");
                PatGenderlbl.Text = selectedRow.Cells[4].Value.ToString();
                Patbgrouplbl.Text = selectedRow.Cells[5].Value.ToString();

                int patientId = Convert.ToInt32(selectedRow.Cells[0].Value);

                btnUpdate.Tag = patientId.ToString();
            }
        }

        private void txtPatient_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string patientFName = txtPatient.Text.Trim();
                string query;

                if (string.IsNullOrEmpty(patientFName))
                {

                    query = "SELECT * FROM DiagnosisTbl";
                }
                else
                {

                    query = "SELECT * FROM DiagnosisTbl WHERE PatientFName LIKE @PatientFName";
                }

                DataTable dt = Con.GetData(query);

                if (!string.IsNullOrEmpty(patientFName))
                {

                    dt.DefaultView.RowFilter = $"PatientFName LIKE '%{patientFName}%'";
                }
                else
                {
                    dt.DefaultView.RowFilter = string.Empty;
                }

                DiagnosisList.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DiagnosisList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = DiagnosisList.Rows[e.RowIndex];

                Symlbl.Text = selectedRow.Cells[6].Value.ToString();
                Diaglbl.Text = selectedRow.Cells[4].Value.ToString();
                Medlbl.Text = selectedRow.Cells[7].Value.ToString();

                int DiagnosisId = Convert.ToInt32(selectedRow.Cells[0].Value);

                btnUpdate.Tag = DiagnosisId.ToString();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;

            float leftMargin = 50;
            float topMargin = 50;
            float pageWidth = e.PageBounds.Width - leftMargin * 2;

            Font titleFont = new Font("Arial", 20, FontStyle.Bold | FontStyle.Italic);
            Font subheadingFont = new Font("Arial", 14, FontStyle.Bold | FontStyle.Italic);
            Font boldFont = new Font("Arial", 12, FontStyle.Bold);
            Font regularFont = new Font("Arial", 12);

            string hospitalName = "Health Care Plus";
            SizeF hospitalNameSize = graphics.MeasureString(hospitalName, titleFont);
            float x = leftMargin + (pageWidth - hospitalNameSize.Width) / 2;
            PointF titlePosition = new PointF(x, topMargin);
            graphics.DrawString(hospitalName, titleFont, Brushes.Black, titlePosition);

            float lineY = topMargin + hospitalNameSize.Height + 10;

            float lineAfterAddressY; 

            
            string emailLabel = "Email:";
            string email = "Vishwaanupama12@gmail.com";
            float emailY = lineY + 20;
            graphics.DrawString(emailLabel, boldFont, Brushes.Black, leftMargin, emailY);
            graphics.DrawString(email, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(emailLabel, boldFont).Width + 10, emailY);

            string phoneLabel = "Phone:";
            string phoneNumber = "077-654-1091";
            float phoneY = emailY + regularFont.Height + 10;
            graphics.DrawString(phoneLabel, boldFont, Brushes.Black, leftMargin, phoneY);
            graphics.DrawString(phoneNumber, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(phoneLabel, boldFont).Width + 10, phoneY);

            string addressLabel = "Address:";
            string address = "194/A East, Halpanwila, Marawila";
            float addressY = phoneY + regularFont.Height + 10;
            graphics.DrawString(addressLabel, boldFont, Brushes.Black, leftMargin, addressY);
            graphics.DrawString(address, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(addressLabel, boldFont).Width + 10, addressY);

            lineAfterAddressY = addressY + regularFont.Height + 10;
            graphics.DrawLine(Pens.Black, leftMargin, lineAfterAddressY, leftMargin + pageWidth, lineAfterAddressY);

            
            string subheading = "Patient's Diagnosis Report";
            SizeF subheadingSize = graphics.MeasureString(subheading, subheadingFont);
            x = leftMargin + (pageWidth - subheadingSize.Width) / 2;
            float subheadingY = lineAfterAddressY + 20; 
            PointF subheadingPosition = new PointF(x, subheadingY);
            graphics.DrawString(subheading, subheadingFont, Brushes.Black, subheadingPosition);
            graphics.DrawLine(new Pen(Brushes.Black, 2), x, subheadingY + subheadingSize.Height + 5, x + subheadingSize.Width, subheadingY + subheadingSize.Height + 5);

           
            string currentDate = DateTime.Now.ToShortDateString();
            graphics.DrawString(currentDate, regularFont, Brushes.Black, leftMargin, subheadingY + subheadingSize.Height + 10);

           
            float patientInfoY = subheadingY + subheadingSize.Height + 40;
            string[] patientLabels = { "Patient Name:", "Date of Birth:", "Gender:", "Blood Group:", "Symptoms:", "Diagnosis:", "Medicine:" };
            string[] patientValues = { PatNamelbl.Text, PatDoBlbl.Text, PatGenderlbl.Text, Patbgrouplbl.Text, Symlbl.Text, Diaglbl.Text, Medlbl.Text };

            for (int i = 0; i < patientLabels.Length; i++)
            {
                graphics.DrawString(patientLabels[i], boldFont, Brushes.Black, leftMargin, patientInfoY);
                graphics.DrawString(patientValues[i], regularFont, Brushes.Black, leftMargin + 150, patientInfoY);
                patientInfoY += regularFont.Height + 10;
            }

          
            string bottomText1 = "HealthCarePlus HSM";
            SizeF bottomText1Size = graphics.MeasureString(bottomText1, regularFont);
            x = leftMargin + (pageWidth - bottomText1Size.Width) / 2;
            float bottomY = e.PageBounds.Height - regularFont.Height * 2;
            PointF bottomText1Position = new PointF(x, bottomY);
            graphics.DrawString(bottomText1, regularFont, Brushes.Black, bottomText1Position);

            
            string bottomText2 = "Powered By Ride Software Solutions";
            SizeF bottomText2Size = graphics.MeasureString(bottomText2, regularFont);
            x = leftMargin + (pageWidth - bottomText2Size.Width) / 2;
            float bottomY2 = bottomY + regularFont.Height + 5;
            PointF bottomText2Position = new PointF(x, bottomY2);
            graphics.DrawString(bottomText2, regularFont, Brushes.Black, bottomText2Position);

            e.HasMorePages = false;

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument = new PrintDocument();


            printDocument.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }
    }
}
