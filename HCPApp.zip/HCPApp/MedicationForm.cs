﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class MedicationForm : Form
    {
        Functions Con;
        public MedicationForm()
        {
            InitializeComponent();
            Con = new Functions();
            ShowMed();
        }

        private void ShowMed()
        {
            try
            {
                string Query = "Select * from MedicationTbl";
                MedList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMedName.Text == "" || txtMedType.Text == "" || txtMedDesc.Text == "" || txtPrice.Text == "")
                {
                    MessageBox.Show("Missing Some of Some or All of The data!");
                }
                else
                {
                    string MedName = txtMedName.Text;
                    string MedType = txtMedType.Text;
                    string MedDesc = txtMedDesc.Text;
                    decimal Price = decimal.Parse(txtPrice.Text);

                    string Query = "INSERT INTO MedicationTbl (MedicationName, MedicationType, Description, Price) VALUES ('{0}', '{1}', '{2}', '{3}')";
                    Query = string.Format(Query, MedName, MedType, MedDesc, Price); 
                    Con.SetData(Query);
                    ShowMed();
                    MessageBox.Show("Patient Added.");
                    txtMedName.Text = "";
                    txtMedType.Text = "";
                    txtMedDesc.Text = ""; 
                    txtPrice.Text = "";
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
        }

        private void MedList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = MedList.Rows[e.RowIndex];

                // Fill the text boxes, combo boxes, and DateTimePicker with data from the selected row
                txtMedName.Text = selectedRow.Cells["MedicationName"].Value.ToString();
                txtMedType.Text = selectedRow.Cells["MedicationType"].Value.ToString();
                txtMedDesc.Text = selectedRow.Cells["Description"].Value.ToString();
                txtPrice.Text = selectedRow.Cells["Price"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                if (MedList.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = MedList.SelectedRows[0];
                    int medicationId = int.Parse(selectedRow.Cells["MedicationId"].Value.ToString());
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this Medicine?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        Con.DeleteMed(medicationId);
                        MessageBox.Show("Medicine deleted successfully.");
                        ShowMed();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
    
}
