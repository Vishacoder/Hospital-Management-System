﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class RoomForm : Form
    {
        private Functions Con;
        public RoomForm()
        {
            InitializeComponent();
            Con = new Functions();
            ShowRooms();
        }
        private void ShowRooms()
        {
            try
            {
                string Query = "Select * from RoomsTbl";
                RoomsList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }

        private void DoctorList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
