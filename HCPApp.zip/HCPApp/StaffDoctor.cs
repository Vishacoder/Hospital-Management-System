﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class StaffDoctor : Form

    {
        private Functions Con;
        private string staffMemberName;

        public StaffDoctor(string staffMemberName)
        {
            InitializeComponent();
            Con = new Functions();
            this.staffMemberName = staffMemberName;
            ShowDoctors();
        }


        private void GoBackToStaffDashboard()
        {
            this.Close();
            StaffDashboard staffDashboard = new StaffDashboard(staffMemberName);
            staffDashboard.Show();
        }


        private void ShowDoctors()
        {
            try
            {
                string Query = "Select * from DoctorTbl";
                DoctorList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StaffPatient staffpatientForm = new StaffPatient(staffMemberName);
            staffpatientForm.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            StaffDoctor staffDoctorForm = new StaffDoctor(staffMemberName);
            staffDoctorForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            StaffAppointment staffappointmentform = new StaffAppointment(staffMemberName);
            staffappointmentform.Show();
            this.Hide();
        }
       

        
        private void btnHome_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            GoBackToStaffDashboard();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (FirstName.Text == "" || LastName.Text == "" || ComboSpec.SelectedIndex == -1 || ComboDay.SelectedIndex == -1 || ComboTime.SelectedIndex == -1 || txtQualification.Text == "" || txtContact.Text == "" )
                {
                    MessageBox.Show("Missing Some of Some or All of The data!");
                }
                else
                {
                    string FName = FirstName.Text;
                    string LName = LastName.Text;
                    string Specification = ComboSpec.SelectedItem.ToString();
                    string AvailableDay = ComboDay.SelectedItem.ToString();
                    string AvailableTime = ComboTime.SelectedItem.ToString();
                    string Qualify = txtQualification.Text;
                    string Conta = txtContact.Text;
                    
                    string Query = "INSERT INTO DoctorTbl ( FirstName, LastName, Specification, AvailableDay, AvailableTime, Qualification, Contact ) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')";
                    Query = string.Format(Query, FName, LName, Specification, AvailableDay, AvailableTime, Qualify, Conta);
                    Con.SetData(Query);
                    ShowDoctors();
                    MessageBox.Show("Doctor Added.");
                    FirstName.Text = "";
                    LastName.Text = "";
                    ComboSpec.SelectedIndex = -1;
                    ComboDay.SelectedIndex = -1;
                    ComboTime.SelectedIndex = -1;
                    txtQualification.Text = "";
                    txtContact.Text = "";



                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void DoctorList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = DoctorList.Rows[e.RowIndex];
                FirstName.Text = selectedRow.Cells[1].Value.ToString();
                LastName.Text = selectedRow.Cells[2].Value.ToString();
                ComboSpec.SelectedItem = selectedRow.Cells[3].Value.ToString();
                ComboDay.SelectedItem = selectedRow.Cells[4].Value.ToString();
                ComboTime.SelectedItem = selectedRow.Cells[5].Value.ToString();
                txtQualification.Text = selectedRow.Cells[6].Value.ToString();
                txtContact.Text = selectedRow.Cells[7].Value.ToString();

                int doctorId = Convert.ToInt32(selectedRow.Cells[0].Value);

                btnUpdate.Tag = doctorId.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SORRY! You Don't have permission to Update Data");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SORRY! You Don't have permission to Delete Data");
        }
    }
}
