﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class ManageStaff : Form
    {
        StaffClass Con;
        public ManageStaff()
        {
            InitializeComponent();
            Con = new StaffClass();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if all required fields are filled
                if (string.IsNullOrWhiteSpace(txtFName.Text) ||
                    string.IsNullOrWhiteSpace(txtLName.Text) ||
                    string.IsNullOrWhiteSpace(txtEmail.Text) ||
                    string.IsNullOrWhiteSpace(txtUserName.Text) ||
                    string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Missing some of the required data!");
                }
                else
                {
                    // Get values from text boxes
                    string firstName = txtFName.Text;
                    string lastName = txtLName.Text;
                    string email = txtEmail.Text;
                    string userName = txtUserName.Text;
                    string password = txtPassword.Text;

                    // Call the function to add staff member
                    int rowsAffected = Con.AddStaffMember(firstName, lastName, email, userName, password);

                    if (rowsAffected > 0)
                    {
                        // If the insert was successful, show a success message
                        MessageBox.Show("Staff member added successfully.");

                        // Clear the text boxes
                        txtFName.Text = "";
                        txtLName.Text = "";
                        txtEmail.Text = "";
                        txtUserName.Text = "";
                        txtPassword.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Failed to add staff member.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
