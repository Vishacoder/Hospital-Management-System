﻿
namespace HCPApp
{
    partial class StaffAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffAppointment));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ComboRoomName = new System.Windows.Forms.ComboBox();
            this.roomsTblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.hCPAppDBDataSet3 = new HCPApp.HCPAppDBDataSet3();
            this.label28 = new System.Windows.Forms.Label();
            this.AppointmentData = new System.Windows.Forms.DataGridView();
            this.txtCharge = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDocLName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDocFName = new System.Windows.Forms.TextBox();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtPatLName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPatFName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ComboTime = new System.Windows.Forms.ComboBox();
            this.txtPatId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDocId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.DoBPicker = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.roomsTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hCPAppDBDataSet1 = new HCPApp.HCPAppDBDataSet1();
            this.roomsTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hCPAppDBDataSet = new HCPApp.HCPAppDBDataSet();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.Chargelbl = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Timelbl = new System.Windows.Forms.Label();
            this.PatNamelbl = new System.Windows.Forms.Label();
            this.AppDatelbl = new System.Windows.Forms.Label();
            this.DocNamelbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ComboSSpec = new System.Windows.Forms.ComboBox();
            this.DocData = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtSPatient = new System.Windows.Forms.TextBox();
            this.PatData = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.roomsTblTableAdapter = new HCPApp.HCPAppDBDataSetTableAdapters.RoomsTblTableAdapter();
            this.roomsTblTableAdapter1 = new HCPApp.HCPAppDBDataSet1TableAdapters.RoomsTblTableAdapter();
            this.roomsTblTableAdapter2 = new HCPApp.HCPAppDBDataSet3TableAdapters.RoomsTblTableAdapter();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DocData)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatData)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(12, 97);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(93, 575);
            this.panel2.TabIndex = 51;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 89);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 13);
            this.label16.TabIndex = 62;
            this.label16.Text = "Your Account";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(18, 36);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(60, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 61;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click_1);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(28, 470);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 13);
            this.label29.TabIndex = 52;
            this.label29.Text = "Rooms";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(18, 414);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 51;
            this.pictureBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 366);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Appointment";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "Doctor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Patient";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(18, 313);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 47;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(18, 218);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 46;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(18, 124);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-2, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1318, 83);
            this.panel1.TabIndex = 50;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(1250, 23);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(54, 36);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 1;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 83);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel5.Controls.Add(this.ComboRoomName);
            this.panel5.Controls.Add(this.label28);
            this.panel5.Controls.Add(this.AppointmentData);
            this.panel5.Controls.Add(this.txtCharge);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.txtDocLName);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.txtDocFName);
            this.panel5.Controls.Add(this.btnHome);
            this.panel5.Controls.Add(this.btnDelete);
            this.panel5.Controls.Add(this.btnUpdate);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.btnAdd);
            this.panel5.Controls.Add(this.txtPatLName);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.txtPatFName);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.ComboTime);
            this.panel5.Controls.Add(this.txtPatId);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.txtDocId);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.DoBPicker);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Location = new System.Drawing.Point(139, 401);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1137, 246);
            this.panel5.TabIndex = 52;
            // 
            // ComboRoomName
            // 
            this.ComboRoomName.DataSource = this.roomsTblBindingSource2;
            this.ComboRoomName.DisplayMember = "RoomName";
            this.ComboRoomName.FormattingEnabled = true;
            this.ComboRoomName.Location = new System.Drawing.Point(522, 88);
            this.ComboRoomName.Name = "ComboRoomName";
            this.ComboRoomName.Size = new System.Drawing.Size(129, 21);
            this.ComboRoomName.TabIndex = 51;
            this.ComboRoomName.ValueMember = "RoomName";
            // 
            // roomsTblBindingSource2
            // 
            this.roomsTblBindingSource2.DataMember = "RoomsTbl";
            this.roomsTblBindingSource2.DataSource = this.hCPAppDBDataSet3;
            // 
            // hCPAppDBDataSet3
            // 
            this.hCPAppDBDataSet3.DataSetName = "HCPAppDBDataSet3";
            this.hCPAppDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(519, 69);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 17);
            this.label28.TabIndex = 50;
            this.label28.Text = "Room Number";
            // 
            // AppointmentData
            // 
            this.AppointmentData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentData.Location = new System.Drawing.Point(676, 62);
            this.AppointmentData.Name = "AppointmentData";
            this.AppointmentData.Size = new System.Drawing.Size(323, 168);
            this.AppointmentData.TabIndex = 34;
            this.AppointmentData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AppointmentData_CellContentClick);
            // 
            // txtCharge
            // 
            this.txtCharge.Location = new System.Drawing.Point(356, 207);
            this.txtCharge.Name = "txtCharge";
            this.txtCharge.Size = new System.Drawing.Size(129, 20);
            this.txtCharge.TabIndex = 49;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(353, 187);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 17);
            this.label15.TabIndex = 48;
            this.label15.Text = "Charge";
            // 
            // txtDocLName
            // 
            this.txtDocLName.Location = new System.Drawing.Point(191, 201);
            this.txtDocLName.Name = "txtDocLName";
            this.txtDocLName.Size = new System.Drawing.Size(129, 20);
            this.txtDocLName.TabIndex = 47;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(188, 181);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 17);
            this.label11.TabIndex = 46;
            this.label11.Text = "Doctor Last Name";
            // 
            // txtDocFName
            // 
            this.txtDocFName.Location = new System.Drawing.Point(191, 144);
            this.txtDocFName.Name = "txtDocFName";
            this.txtDocFName.Size = new System.Drawing.Size(129, 20);
            this.txtDocFName.TabIndex = 45;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHome.Location = new System.Drawing.Point(1018, 201);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(100, 30);
            this.btnHome.TabIndex = 24;
            this.btnHome.Text = "Go To Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Location = new System.Drawing.Point(1018, 157);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 23;
            this.btnDelete.Text = "Cancel";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdate.Location = new System.Drawing.Point(1018, 110);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 30);
            this.btnUpdate.TabIndex = 22;
            this.btnUpdate.Text = "Reschedule";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(188, 124);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 17);
            this.label10.TabIndex = 44;
            this.label10.Text = "Doctor First Name";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Location = new System.Drawing.Point(1018, 63);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 21;
            this.btnAdd.Text = "Schedule";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtPatLName
            // 
            this.txtPatLName.Location = new System.Drawing.Point(26, 201);
            this.txtPatLName.Name = "txtPatLName";
            this.txtPatLName.Size = new System.Drawing.Size(129, 20);
            this.txtPatLName.TabIndex = 43;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 181);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 17);
            this.label9.TabIndex = 42;
            this.label9.Text = "Patient Last Name";
            // 
            // txtPatFName
            // 
            this.txtPatFName.Location = new System.Drawing.Point(26, 144);
            this.txtPatFName.Name = "txtPatFName";
            this.txtPatFName.Size = new System.Drawing.Size(129, 20);
            this.txtPatFName.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 17);
            this.label6.TabIndex = 40;
            this.label6.Text = "Patient First Name";
            // 
            // ComboTime
            // 
            this.ComboTime.FormattingEnabled = true;
            this.ComboTime.Items.AddRange(new object[] {
            "8.00 - 9.00",
            "9.00-10.00",
            "10.00-11.00",
            "11.00-12.00",
            "12.00-13.00",
            "13.00-14.00",
            "14.00-15.00",
            "15.00-16.00",
            "16.00-17.00",
            "17.00-18.00",
            "18.00-19.00",
            "19.00-20.00",
            "21.00-22.00"});
            this.ComboTime.Location = new System.Drawing.Point(356, 150);
            this.ComboTime.Name = "ComboTime";
            this.ComboTime.Size = new System.Drawing.Size(129, 21);
            this.ComboTime.TabIndex = 34;
            // 
            // txtPatId
            // 
            this.txtPatId.Location = new System.Drawing.Point(26, 89);
            this.txtPatId.Name = "txtPatId";
            this.txtPatId.Size = new System.Drawing.Size(129, 20);
            this.txtPatId.TabIndex = 39;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(23, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 17);
            this.label7.TabIndex = 38;
            this.label7.Text = "Patient ID";
            // 
            // txtDocId
            // 
            this.txtDocId.Location = new System.Drawing.Point(191, 89);
            this.txtDocId.Name = "txtDocId";
            this.txtDocId.Size = new System.Drawing.Size(129, 20);
            this.txtDocId.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(353, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "Appointment Date";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(188, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 17);
            this.label12.TabIndex = 36;
            this.label12.Text = "Doctor ID";
            // 
            // DoBPicker
            // 
            this.DoBPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DoBPicker.Location = new System.Drawing.Point(356, 89);
            this.DoBPicker.Name = "DoBPicker";
            this.DoBPicker.Size = new System.Drawing.Size(131, 20);
            this.DoBPicker.TabIndex = 29;
            this.DoBPicker.Value = new System.DateTime(2023, 9, 7, 0, 0, 0, 0);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(353, 130);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 17);
            this.label13.TabIndex = 16;
            this.label13.Text = "Time";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Brown;
            this.label14.Location = new System.Drawing.Point(490, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 17);
            this.label14.TabIndex = 9;
            this.label14.Text = "Appointments";
            // 
            // roomsTblBindingSource1
            // 
            this.roomsTblBindingSource1.DataMember = "RoomsTbl";
            this.roomsTblBindingSource1.DataSource = this.hCPAppDBDataSet1;
            // 
            // hCPAppDBDataSet1
            // 
            this.hCPAppDBDataSet1.DataSetName = "HCPAppDBDataSet1";
            this.hCPAppDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // roomsTblBindingSource
            // 
            this.roomsTblBindingSource.DataMember = "RoomsTbl";
            this.roomsTblBindingSource.DataSource = this.hCPAppDBDataSet;
            // 
            // hCPAppDBDataSet
            // 
            this.hCPAppDBDataSet.DataSetName = "HCPAppDBDataSet";
            this.hCPAppDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightBlue;
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.btnPrint);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.Chargelbl);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.label27);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.Timelbl);
            this.panel6.Controls.Add(this.PatNamelbl);
            this.panel6.Controls.Add(this.AppDatelbl);
            this.panel6.Controls.Add(this.DocNamelbl);
            this.panel6.Location = new System.Drawing.Point(139, 110);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(471, 255);
            this.panel6.TabIndex = 71;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(50, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 17);
            this.label20.TabIndex = 58;
            this.label20.Text = "Patient";
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnPrint.FlatAppearance.BorderSize = 0;
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPrint.Location = new System.Drawing.Point(356, 209);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(100, 30);
            this.btnPrint.TabIndex = 50;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(291, 32);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 17);
            this.label22.TabIndex = 56;
            this.label22.Text = "Time";
            // 
            // Chargelbl
            // 
            this.Chargelbl.AutoSize = true;
            this.Chargelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chargelbl.Location = new System.Drawing.Point(291, 104);
            this.Chargelbl.Name = "Chargelbl";
            this.Chargelbl.Size = new System.Drawing.Size(54, 17);
            this.Chargelbl.TabIndex = 67;
            this.Chargelbl.Text = "Charge";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(52, 148);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(137, 17);
            this.label21.TabIndex = 57;
            this.label21.Text = "Appointment Date";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(291, 87);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 17);
            this.label27.TabIndex = 66;
            this.label27.Text = "Charge";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(52, 87);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 17);
            this.label19.TabIndex = 59;
            this.label19.Text = "Doctor";
            // 
            // Timelbl
            // 
            this.Timelbl.AutoSize = true;
            this.Timelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Timelbl.Location = new System.Drawing.Point(291, 49);
            this.Timelbl.Name = "Timelbl";
            this.Timelbl.Size = new System.Drawing.Size(39, 17);
            this.Timelbl.TabIndex = 64;
            this.Timelbl.Text = "Time";
            // 
            // PatNamelbl
            // 
            this.PatNamelbl.AutoEllipsis = true;
            this.PatNamelbl.AutoSize = true;
            this.PatNamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatNamelbl.Location = new System.Drawing.Point(50, 49);
            this.PatNamelbl.Name = "PatNamelbl";
            this.PatNamelbl.Size = new System.Drawing.Size(52, 17);
            this.PatNamelbl.TabIndex = 61;
            this.PatNamelbl.Text = "Patient";
            // 
            // AppDatelbl
            // 
            this.AppDatelbl.AutoSize = true;
            this.AppDatelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppDatelbl.Location = new System.Drawing.Point(52, 165);
            this.AppDatelbl.Name = "AppDatelbl";
            this.AppDatelbl.Size = new System.Drawing.Size(121, 17);
            this.AppDatelbl.TabIndex = 63;
            this.AppDatelbl.Text = "Appointment Date";
            // 
            // DocNamelbl
            // 
            this.DocNamelbl.AutoSize = true;
            this.DocNamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocNamelbl.Location = new System.Drawing.Point(52, 104);
            this.DocNamelbl.Name = "DocNamelbl";
            this.DocNamelbl.Size = new System.Drawing.Size(50, 17);
            this.DocNamelbl.TabIndex = 62;
            this.DocNamelbl.Text = "Doctor";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Controls.Add(this.ComboSSpec);
            this.panel3.Controls.Add(this.DocData);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(619, 110);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(322, 255);
            this.panel3.TabIndex = 69;
            // 
            // ComboSSpec
            // 
            this.ComboSSpec.FormattingEnabled = true;
            this.ComboSSpec.Items.AddRange(new object[] {
            "Abdomen",
            "Accupuncture Physician",
            "Acting Consultant Endocrinologist",
            "Allergy And ImmunologyAnomaly Scan",
            "Aryuvedic Physician",
            "Bacteriologist",
            "Brain Scalp",
            "Breast Care Clinic",
            "Cancer Surgeon",
            "Cardiaologist",
            "Chest Physician",
            "Dental Surgeon",
            "Dentist",
            "Dermatologist",
            "Dietician",
            "Eye Surgeon",
            "Gastroenterologist",
            "Gastrologist",
            "Hypotherapist",
            "Oncologist",
            "Pysician",
            "Radiologist",
            "Sport Physician"});
            this.ComboSSpec.Location = new System.Drawing.Point(19, 55);
            this.ComboSSpec.Name = "ComboSSpec";
            this.ComboSSpec.Size = new System.Drawing.Size(138, 21);
            this.ComboSSpec.TabIndex = 33;
            // 
            // DocData
            // 
            this.DocData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DocData.Location = new System.Drawing.Point(18, 95);
            this.DocData.Name = "DocData";
            this.DocData.Size = new System.Drawing.Size(288, 144);
            this.DocData.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 17);
            this.label5.TabIndex = 32;
            this.label5.Text = "Search Specification";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel4.Controls.Add(this.txtSPatient);
            this.panel4.Controls.Add(this.PatData);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(954, 110);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(322, 255);
            this.panel4.TabIndex = 70;
            // 
            // txtSPatient
            // 
            this.txtSPatient.Location = new System.Drawing.Point(20, 56);
            this.txtSPatient.Name = "txtSPatient";
            this.txtSPatient.Size = new System.Drawing.Size(138, 20);
            this.txtSPatient.TabIndex = 35;
            // 
            // PatData
            // 
            this.PatData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PatData.Location = new System.Drawing.Point(20, 95);
            this.PatData.Name = "PatData";
            this.PatData.Size = new System.Drawing.Size(283, 144);
            this.PatData.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "Search Patient Name";
            // 
            // roomsTblTableAdapter
            // 
            this.roomsTblTableAdapter.ClearBeforeFill = true;
            // 
            // roomsTblTableAdapter1
            // 
            this.roomsTblTableAdapter1.ClearBeforeFill = true;
            // 
            // roomsTblTableAdapter2
            // 
            this.roomsTblTableAdapter2.ClearBeforeFill = true;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // StaffAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Brown;
            this.ClientSize = new System.Drawing.Size(1314, 671);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StaffAppointment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StaffAppointment";
            this.Load += new System.EventHandler(this.StaffAppointment_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hCPAppDBDataSet)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DocData)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtDocLName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDocFName;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtPatLName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.TextBox txtPatFName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ComboTime;
        private System.Windows.Forms.TextBox txtPatId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDocId;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker DoBPicker;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCharge;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView AppointmentData;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label Chargelbl;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label Timelbl;
        private System.Windows.Forms.Label PatNamelbl;
        private System.Windows.Forms.Label AppDatelbl;
        private System.Windows.Forms.Label DocNamelbl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox ComboSSpec;
        private System.Windows.Forms.DataGridView DocData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtSPatient;
        private System.Windows.Forms.DataGridView PatData;
        private System.Windows.Forms.Label label4;
        private HCPAppDBDataSet hCPAppDBDataSet;
        private System.Windows.Forms.BindingSource roomsTblBindingSource;
        private HCPAppDBDataSetTableAdapters.RoomsTblTableAdapter roomsTblTableAdapter;
        private HCPAppDBDataSet1 hCPAppDBDataSet1;
        private System.Windows.Forms.BindingSource roomsTblBindingSource1;
        private HCPAppDBDataSet1TableAdapters.RoomsTblTableAdapter roomsTblTableAdapter1;
        private System.Windows.Forms.ComboBox ComboRoomName;
        private HCPAppDBDataSet3 hCPAppDBDataSet3;
        private System.Windows.Forms.BindingSource roomsTblBindingSource2;
        private HCPAppDBDataSet3TableAdapters.RoomsTblTableAdapter roomsTblTableAdapter2;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}