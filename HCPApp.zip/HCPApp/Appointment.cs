﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace HCPApp
{
    public partial class Appointment : Form
    {
        Functions Con;
        public Appointment()
        {
            InitializeComponent();
            Con = new Functions();
            PatShow();
            DocShow();
            AppShow();
        }
        public void PatShow()
        {
            try
            {
                String Query = "Select * from PatientTbl";
                PatData.DataSource = Con.GetData(Query);
            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        public void DocShow()
        {
            try
            {
                string Query = "Select * from DoctorTbl";
                DocData.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        public void AppShow()
        {
            try
            {
                String Query = "Select * from AppointmentTbl";
                AppointmentData.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }
        private void ComboSSpec_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSpec = ComboSSpec.SelectedItem.ToString();

            DataView dv = new DataView(Con.GetData("Select * from DoctorTbl"));
            dv.RowFilter = $"Specification = '{selectedSpec}'";

            DocData.DataSource = dv;
        }
        private void txtSPatient_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string patientFirstName = txtSPatient.Text.Trim();
                string query;

                if (string.IsNullOrEmpty(patientFirstName))
                {
                   
                    query = "SELECT * FROM PatientTbl";
                }
                else
                {
                    // If there's text in the TextBox, filter by first name
                    query = "SELECT * FROM PatientTbl WHERE FirstName LIKE @FirstName";
                }

                DataTable dt = Con.GetData(query);

                if (!string.IsNullOrEmpty(patientFirstName))
                {
                    // If there's text, add a parameter for filtering
                    dt.DefaultView.RowFilter = $"FirstName LIKE '%{patientFirstName}%'";
                }
                else
                {
                    dt.DefaultView.RowFilter = string.Empty;
                }

                PatData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void DocData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int patientId = int.Parse(txtPatId.Text);
                string patFName = txtPatFName.Text;
                string patLName = txtPatLName.Text;
                int doctorId = int.Parse(txtDocId.Text);
                string docFName = txtDocFName.Text;
                string docLName = txtDocLName.Text;
                DateTime appointmentDate = DoBPicker.Value;
                string appointmentTime = ComboTime.SelectedItem.ToString();
                int appointmentNumber = Con.GetNextAppointmentNumber();
                decimal charge = decimal.Parse(txtCharge.Text);
                Con.AddAppointment(patientId, patFName, patLName, doctorId, docFName, docLName, appointmentDate, appointmentTime, appointmentNumber, charge);
                MessageBox.Show("Appointment added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int patientId = int.Parse(txtPatId.Text);
                string patFName = txtPatFName.Text;
                string patLName = txtPatLName.Text;
                int doctorId = int.Parse(txtDocId.Text);
                string docFName = txtDocFName.Text;
                string docLName = txtDocLName.Text;
                DateTime appointmentDate = DoBPicker.Value;
                string appointmentTime = ComboTime.SelectedItem.ToString();
                decimal charge = decimal.Parse(txtCharge.Text);
                Con.UpdateAppointment(patientId, patFName, patLName, doctorId, docFName, docLName, appointmentDate, appointmentTime, charge);
                MessageBox.Show("Appointment updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
           
                if (AppointmentData.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = AppointmentData.SelectedRows[0];
                    int appointmentId = int.Parse(selectedRow.Cells["AppointmentId"].Value.ToString());
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this appointment?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        Con.DeleteAppointment(appointmentId);
                        MessageBox.Show("Appointment deleted successfully.");
                        AppShow();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void AppointmentData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = AppointmentData.Rows[e.RowIndex];

                // Fill the text boxes, combo boxes, and DateTimePicker with data from the selected row
                txtPatId.Text = selectedRow.Cells["PatientId"].Value.ToString();
                txtPatFName.Text = selectedRow.Cells["PatFName"].Value.ToString();
                txtPatLName.Text = selectedRow.Cells["PatLName"].Value.ToString();
                txtDocId.Text = selectedRow.Cells["DoctorId"].Value.ToString();
                txtDocFName.Text = selectedRow.Cells["DocFName"].Value.ToString();
                txtDocLName.Text = selectedRow.Cells["DocLName"].Value.ToString();
                DoBPicker.Value = (DateTime)selectedRow.Cells["AppointmentDate"].Value;
                ComboTime.SelectedItem = selectedRow.Cells["AppointmentTime"].Value.ToString();
                txtCharge.Text = selectedRow.Cells["Charge"].Value.ToString();
                PatNamelbl.Text = selectedRow.Cells["PatFName"].Value.ToString() + " " + selectedRow.Cells["PatLName"].Value.ToString();
                DocNamelbl.Text = selectedRow.Cells["DocFName"].Value.ToString() + " " + selectedRow.Cells["DocLName"].Value.ToString();
                AppDatelbl.Text = ((DateTime)selectedRow.Cells["AppointmentDate"].Value).ToString("yyyy-MM-dd");
                Timelbl.Text = selectedRow.Cells["AppointmentTime"].Value.ToString();
                Chargelbl.Text = selectedRow.Cells["Charge"].Value.ToString();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
           
            PrintDocument printDocument = new PrintDocument();

          
            printDocument.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           
            Graphics graphics = e.Graphics;

          
            float leftMargin = 50;
            float topMargin = 50; 
            float pageWidth = e.PageBounds.Width - leftMargin * 2;

           
            Font titleFont = new Font("Arial", 20, FontStyle.Bold | FontStyle.Italic);
            Font boldFont = new Font("Arial", 12, FontStyle.Bold);
            Font regularFont = new Font("Arial", 12);

           
            string hospitalName = "Health Care Plus";
            SizeF hospitalNameSize = graphics.MeasureString(hospitalName, titleFont);
            float x = leftMargin + (pageWidth - hospitalNameSize.Width) / 2;
            PointF titlePosition = new PointF(x, topMargin);
            graphics.DrawString(hospitalName, titleFont, Brushes.Black, titlePosition);

            
            string emailLabel = "Email:";
            string email = "Vishwaanupama12@gmail.com";
            float emailY = topMargin + hospitalNameSize.Height + 20; 
            graphics.DrawString(emailLabel, boldFont, Brushes.Black, leftMargin, emailY);
            graphics.DrawString(email, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(emailLabel, boldFont).Width + 10, emailY);

            
            string phoneLabel = "Phone:";
            string phoneNumber = "077 654 1091";             float phoneY = emailY + regularFont.Height + 10; 
            graphics.DrawString(phoneLabel, boldFont, Brushes.Black, leftMargin, phoneY);
            graphics.DrawString(phoneNumber, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(phoneLabel, boldFont).Width + 10, phoneY);

           
            string addressLabel = "Address:";
            string address = "194/A East Halpanwila Marawila"; 
            float addressY = phoneY + regularFont.Height + 10; 
            graphics.DrawString(addressLabel, boldFont, Brushes.Black, leftMargin, addressY);
            graphics.DrawString(address, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(addressLabel, boldFont).Width + 10, addressY);

            
            float lineY = topMargin + hospitalNameSize.Height + 10; 
            graphics.DrawLine(Pens.Black, leftMargin, lineY, leftMargin + pageWidth, lineY);

           
            float lineAfterAddressY = addressY + regularFont.Height + 10; 
            graphics.DrawLine(Pens.Black, leftMargin, lineAfterAddressY, leftMargin + pageWidth, lineAfterAddressY);

            
            Font receiptTitleFont = new Font("Arial", 16, FontStyle.Bold | FontStyle.Underline);
            string receiptTitle = "Appointment Receipt";
            SizeF receiptTitleSize = graphics.MeasureString(receiptTitle, receiptTitleFont);
            float receiptX = leftMargin + (pageWidth - receiptTitleSize.Width) / 2;
            float receiptY = lineAfterAddressY + 20; 
            PointF receiptTitlePosition = new PointF(receiptX, receiptY);
            graphics.DrawString(receiptTitle, receiptTitleFont, Brushes.Black, receiptTitlePosition);

            
            string patientNameLabel = "Patient Name:";
            string patientName = PatNamelbl.Text; 
            float patientNameY = receiptY + receiptTitleSize.Height + 10;
            graphics.DrawString(patientNameLabel, boldFont, Brushes.Black, leftMargin, patientNameY);
            graphics.DrawString(patientName, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(patientNameLabel, boldFont).Width + 10, patientNameY);

           
            string doctorNameLabel = "Doctor Name:";
            string doctorName = DocNamelbl.Text; 
            float doctorNameY = patientNameY + receiptTitleSize.Height + 10;
            graphics.DrawString(doctorNameLabel, boldFont, Brushes.Black, leftMargin, doctorNameY);
            graphics.DrawString(doctorName, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(doctorNameLabel, boldFont).Width + 10, doctorNameY);

           
            string appointmentdateLabel = "Appointment Date:";
            string appointmentdate = AppDatelbl.Text; 
            float appointmentdateY = doctorNameY + receiptTitleSize.Height + 10; 
            graphics.DrawString(appointmentdateLabel, boldFont, Brushes.Black, leftMargin, appointmentdateY);
            graphics.DrawString(appointmentdate, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(appointmentdateLabel, boldFont).Width + 10, appointmentdateY);

            
            string appointmenttimeLabel = "Appointment Time:";
            string appointmenttime = Timelbl.Text; 
            float appointmenttimeY = appointmentdateY + receiptTitleSize.Height + 10; 
            graphics.DrawString(appointmenttimeLabel, boldFont, Brushes.Black, leftMargin, appointmenttimeY);
            graphics.DrawString(appointmenttime, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(appointmenttimeLabel, boldFont).Width + 10, appointmenttimeY);


            
            decimal charge = decimal.Parse(Chargelbl.Text); 
            decimal extraCharge = 50.0m; 
            decimal totalCharge = charge + extraCharge;

            
            string chargeLabel = "Doctor Charge:";
            string chargeValue = charge.ToString("C"); 
            float chargeLabelWidth = graphics.MeasureString(chargeLabel, boldFont).Width;
            float chargeValueX = leftMargin + pageWidth - chargeLabelWidth - 100;
            float chargeY = appointmenttimeY + receiptTitleSize.Height + 10; 
            graphics.DrawString(chargeLabel, boldFont, Brushes.Black, chargeValueX, chargeY);
            graphics.DrawString(chargeValue.Replace("£", "LKR"), regularFont, Brushes.Black, chargeValueX + chargeLabelWidth + 10, chargeY);

          
            string hospitalChargeLabel = "Hospital Charge:";
            decimal hospitalChargeValue = 500.0m; 
            string hospitalChargeValueText = hospitalChargeValue.ToString("C"); 
            float hospitalChargeLabelWidth = graphics.MeasureString(hospitalChargeLabel, boldFont).Width;
            float hospitalChargeValueX = leftMargin + pageWidth - hospitalChargeLabelWidth - 100; 
            float hospitalChargeY = chargeY + regularFont.Height + 10; 
            graphics.DrawString(hospitalChargeLabel, boldFont, Brushes.Black, hospitalChargeValueX, hospitalChargeY);
            graphics.DrawString(hospitalChargeValueText.Replace("£", "LKR"), regularFont, Brushes.Black, hospitalChargeValueX + hospitalChargeLabelWidth + 10, hospitalChargeY);

          
            float lineUnderHospitalChargeY = hospitalChargeY + regularFont.Height + 10; 
            graphics.DrawLine(Pens.Black, hospitalChargeValueX, lineUnderHospitalChargeY, leftMargin + pageWidth, lineUnderHospitalChargeY);

           
            string totalLabel = "Total:";
            decimal totalValue = totalCharge + hospitalChargeValue; 
            string totalValueText = totalValue.ToString("C"); 
            float totalLabelWidth = graphics.MeasureString(totalLabel, boldFont).Width;
            float totalValueX = leftMargin + pageWidth - totalLabelWidth - 100; 
            float totalY = lineUnderHospitalChargeY + 10; 
            graphics.DrawString(totalLabel, boldFont, Brushes.Black, totalValueX, totalY);
            graphics.DrawString(totalValueText.Replace("£", "LKR"), regularFont, Brushes.Black, totalValueX + totalLabelWidth + 10, totalY);
        
            float line1Y = totalY + regularFont.Height + 5; 
            float line2Y = line1Y + 5; 
            graphics.DrawLine(Pens.Black, totalValueX, line1Y, leftMargin + pageWidth, line1Y);
            graphics.DrawLine(Pens.Black, totalValueX, line2Y, leftMargin + pageWidth, line2Y);
      
            e.HasMorePages = false;

            string bottomText1 = "Health Care Plus HMS";
            string bottomText2 = "Powered By Ride Software Solutions";
        
            Font bottomFont1 = new Font("Arial", 12);
            Font bottomFont2 = new Font("Arial", 10);
            Brush bottomBrush1 = Brushes.Brown;
            Brush bottomBrush2 = Brushes.Black; 
         
            float PageWidth = e.PageBounds.Width;
            float pageHeight = e.PageBounds.Height;
          
            SizeF textSize1 = e.Graphics.MeasureString(bottomText1, bottomFont1);
            SizeF textSize2 = e.Graphics.MeasureString(bottomText2, bottomFont2);

            float textX1 = (PageWidth - textSize1.Width) / 2;
            float textX2 = (PageWidth - textSize2.Width) / 2;
            float textY1 = pageHeight - textSize1.Height - 30;
            float textY2 = textY1 + textSize1.Height + 2;

            e.Graphics.DrawString(bottomText1, bottomFont1, bottomBrush1, textX1, textY1);
            e.Graphics.DrawString(bottomText2, bottomFont2, bottomBrush2, textX2, textY2);
        }
    }
}
