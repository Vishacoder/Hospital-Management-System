﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace HCPApp
{
    class StaffClass
    {
        public string StaffMemberName { get; private set; }
        private SqlConnection Con;
        private SqlCommand cmd;
        private DataTable dt;
        private SqlDataAdapter sda;
        private string Constr;


        public StaffClass()
        {
            Constr = @"Data Source=LAPTOP-A9K7TF0H\SQLEXPRESS;Initial Catalog=HCPAppDB;Integrated Security=True";
            Con = new SqlConnection(Constr);
            cmd = new SqlCommand();
            cmd.Connection = Con;
        }


        public int AddStaffMember(string firstName, string lastName, string email, string userName, string password)
        {
            string query = "INSERT INTO StaffTbl (FirstName, LastName, Email, UserName, Password) " +
                           "VALUES (@FirstName, @LastName, @Email, @UserName, @Password)";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@UserName", userName);
                command.Parameters.AddWithValue("@Password", password);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                return rowsAffected;
            }
        }



        public string[] GetUserProfileInformation(string staffMemberName)
        {
            string[] userInfo = new string[3];

            string query = "SELECT FirstName, LastName, Email FROM StaffTbl WHERE UserName = @UserName";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@UserName", staffMemberName);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        userInfo[0] = reader["FirstName"].ToString();
                        userInfo[1] = reader["LastName"].ToString();
                        userInfo[2] = reader["Email"].ToString();
                    }
                }
            }

            return userInfo;
        }

    }



}
