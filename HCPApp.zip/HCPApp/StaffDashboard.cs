﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class StaffDashboard : Form
    {
        private string staffMemberName;
        public StaffDashboard(string staffMemberName)
        {
            InitializeComponent();
            this.staffMemberName = staffMemberName; // Assign the value
            welcomeLabel.Text = $"{staffMemberName}!";

        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StaffPatient staffpatient = new StaffPatient(staffMemberName);
            staffpatient.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            StaffDoctor staffDoctorForm = new StaffDoctor(staffMemberName);
            staffDoctorForm.Show();
            this.Hide();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            StaffAppointment staffappointmentForm = new StaffAppointment(staffMemberName);
            staffappointmentForm.Show();
            this.Hide();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManageProfileForm manageProfileForm = new ManageProfileForm(staffMemberName);
            manageProfileForm.Show();
            this.Hide();
        }
    }
}
