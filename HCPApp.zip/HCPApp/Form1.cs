﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HCPApp;

using System.Data.SqlClient;

namespace HCPApp
{
    public partial class Form1 : Form
    {
        private Functions Con;
        public Form1()
        {
            InitializeComponent();
            Con = new Functions();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUserName.Text.Trim();
            string password = txtPassword.Text.Trim();
            string currentUser = UserManager.CurrentUsername;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            bool isAdmin = rbAdmin.Checked;

            if (isAdmin)
            {
                // Admin login successful
                UserManager.SetCurrentUser(username);
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.Show();
                this.Hide();
            }
            else
            {
                if (Con.IsValidStaffCredentials(username, password))
                {
                    string staffMemberName = Con.GetStaffMemberName(username);

                    if (!string.IsNullOrEmpty(staffMemberName))
                    {
                        // Staff login successful
                        UserManager.SetCurrentUser(username); // Set the current user
                        StaffDashboard staffDashboard = new StaffDashboard(staffMemberName);
                        staffDashboard.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid staff credentials. Please try again.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid staff credentials. Please try again.");
                }
            }

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
