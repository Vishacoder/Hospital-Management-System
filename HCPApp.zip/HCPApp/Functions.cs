﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace HCPApp
{
    class Functions
    {
        public string StaffMemberName { get; private set; }
        private SqlConnection Con;
        private SqlCommand cmd;
        private DataTable dt;
        private SqlDataAdapter sda;
        private string Constr;
        public Functions()
        {
            Constr = @"Data Source=LAPTOP-A9K7TF0H\SQLEXPRESS;Initial Catalog=HCPAppDB;Integrated Security=True";
            Con = new SqlConnection(Constr);
            cmd = new SqlCommand();
            cmd.Connection = Con;
        }

        public void OpenConnection()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        public void CloseConnection()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        public DataTable GetData(string Query)
        {
            dt = new DataTable();
            sda = new SqlDataAdapter(Query, Constr);
            sda.Fill(dt);
            return dt;
        }

        public int SetData(string Query)
        {
            int Cnt = 0;
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
            cmd.CommandText = Query;
            Cnt = cmd.ExecuteNonQuery();
            Con.Close();
            return Cnt;
        }




        //Login Table



        public bool IsValidAdminCredentials(string username, string password)
        {
            string query = "SELECT AdminID FROM AdminTbl WHERE Username = @Username AND Password = @Password";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                SqlDataReader reader = command.ExecuteReader();

                bool isValid = reader.HasRows;

                reader.Close();
                return isValid;
            }
        }

        public bool IsValidStaffCredentials(string username, string password)
        {
            string query = "SELECT StaffID FROM StaffTbl WHERE Username = @Username AND Password = @Password";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                SqlDataReader reader = command.ExecuteReader();

                bool isValid = reader.HasRows;

                reader.Close();
                return isValid;
            }
        }
        public string GetStaffMemberName(string username)
        {
            using (SqlConnection connection = new SqlConnection(Con.ConnectionString))
            {
                string query = "SELECT FirstName FROM StaffTbl WHERE UserName = @Username";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);

                try
                {
                    connection.Open();
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        StaffMemberName = result.ToString();
                    }
                    else
                    {
                        StaffMemberName = string.Empty;
                    }
                }
                catch (Exception ex)
                {
                    StaffMemberName = string.Empty;
                }
                finally
                {
                    connection.Close();
                }
            }

            return StaffMemberName;
        }






        //Doctor table




        public int GetDoctorIdByDetails(string firstName, string lastName, string specification, string availableDay, string availableTime)
        {
            int doctorId = -1;

            string query = "SELECT DoctorId FROM DoctorTbl WHERE FirstName = @FirstName AND LastName = @LastName AND Specification = @Specification AND AvailableDay = @AvailableDay AND AvailableTime = @AvailableTime";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@Specification", specification);
                command.Parameters.AddWithValue("@AvailableDay", availableDay);
                command.Parameters.AddWithValue("@AvailableTime", availableTime);

                object result = command.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {
                    doctorId = Convert.ToInt32(result);
                }
            }

            return doctorId;
        }
        public int UpdateDoctorInfo(int doctorId, string firstName, string lastName, string specification, string availableDay, string availableTime, string qualification, string contact, string connectionString)
        {
            string query = "UPDATE DoctorTbl SET FirstName = @FirstName, LastName = @LastName, Specification = @Specification, AvailableDay = @AvailableDay, AvailableTime = @AvailableTime, Qualification = @Qualification, Contact = @Contact WHERE DoctorId = @DoctorId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@Specification", specification);
                command.Parameters.AddWithValue("@AvailableDay", availableDay);
                command.Parameters.AddWithValue("@AvailableTime", availableTime);
                command.Parameters.AddWithValue("@Qualification", qualification);
                command.Parameters.AddWithValue("@Contact", contact);
                command.Parameters.AddWithValue("@DoctorId", doctorId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }

        }

        public int DeleteDoctor(int doctorId, string connectionString)
        {
            string query = "DELETE FROM DoctorTbl WHERE DoctorId = @DoctorId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@DoctorId", doctorId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }
        }


        //********************Patient********************* 
        public int UpdatePatientInfo(int patientId, string firstName, string lastName, DateTime dob, string gender, string bloodGroup, string contact, string medicalHistory, string allergies, string connectionString)
        {
            string query = "UPDATE PatientTbl SET FirstName = @FirstName, LastName = @LastName, DoB = @DoB, Gender = @Gender, BloodGroup = @BloodGroup, PatientContact = @PatientContact, MedicalHistory = @MedicalHistory, Allergies = @Allergies WHERE PatientId = @PatientId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@DoB", dob);
                command.Parameters.AddWithValue("@Gender", gender);
                command.Parameters.AddWithValue("@BloodGroup", bloodGroup);
                command.Parameters.AddWithValue("@PatientContact", contact);
                command.Parameters.AddWithValue("@MedicalHistory", medicalHistory);
                command.Parameters.AddWithValue("@Allergies", allergies);
                command.Parameters.AddWithValue("@PatientId", patientId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }
        }
        public int DeletePatient(int patientId, string connectionString)
        {
            string query = "DELETE FROM PatientTbl WHERE PatientId = @PatientId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@PatientId", patientId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }
        }




        //************************Reports****************************
 
        public int GetPatientCount()
        {
            string query = "SELECT COUNT(*) FROM PatientTbl";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                int patientCount = (int)command.ExecuteScalar();
                connection.Close();

                return patientCount;
            }
        }

        public object ExecuteScalar(string query)
        {
            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                return command.ExecuteScalar();
            }
        }
        //***********************Appointment************************

        public void AddAppointment(int patientId, string patFName, string patLName, int doctorId, string docFName, string docLName, DateTime appointmentDate, string appointmentTime, int appointmentNumber, decimal charge)
        {
            try
            {
                Con.Open();
                string query = "INSERT INTO AppointmentTbl (PatientId, PatFName, PatLName, DoctorId, DocFName, DocLName, AppointmentDate, AppointmentTime, AppointmentNumber, Charge) " +
                               "VALUES (@PatientId, @PatFName, @PatLName, @DoctorId, @DocFName, @DocLName, @AppointmentDate,@AppointmentTime, @AppointmentNumber, @Charge)";
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@PatientId", patientId);
                cmd.Parameters.AddWithValue("@PatFName", patFName);
                cmd.Parameters.AddWithValue("@PatLName", patLName);
                cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                cmd.Parameters.AddWithValue("@DocFName", docFName);
                cmd.Parameters.AddWithValue("@DocLName", docLName);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                cmd.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                cmd.Parameters.AddWithValue("@AppointmentNumber", appointmentNumber);
                cmd.Parameters.AddWithValue("@Charge", charge);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Con.Close();
            }
        }
        public int GetNextAppointmentNumber()
        {
            try
            {
                OpenConnection();
                string query = "SELECT ISNULL(MAX(AppointmentNumber), 0) + 1 FROM AppointmentTbl";
                cmd.CommandText = query;
                int nextAppointmentNumber = (int)cmd.ExecuteScalar();
                return nextAppointmentNumber;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }
        public void UpdateAppointment(int patientId, string patFName, string patLName, int doctorId, string docFName, string docLName, DateTime appointmentDate, string appointmentTime, decimal charge)
        {
            try
            {
                OpenConnection();
                string query = "UPDATE AppointmentTbl " +
                               "SET PatFName = @PatFName, PatLName = @PatLName, " +
                               "DoctorId = @DoctorId, DocFName = @DocFName, " +
                               "DocLName = @DocLName, AppointmentDate = @AppointmentDate, " +
                               "AppointmentTime = @AppointmentTime, Charge = @Charge " +
                               "WHERE PatientId = @PatientId";

                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@PatientId", patientId);
                cmd.Parameters.AddWithValue("@PatFName", patFName);
                cmd.Parameters.AddWithValue("@PatLName", patLName);
                cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                cmd.Parameters.AddWithValue("@DocFName", docFName);
                cmd.Parameters.AddWithValue("@DocLName", docLName);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                cmd.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                cmd.Parameters.AddWithValue("@Charge", charge);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        public void DeleteAppointment(int appointmentId)
        {
            try
            {
                OpenConnection();
                string query = "DELETE FROM AppointmentTbl WHERE AppointmentId = @AppointmentId";
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@AppointmentId", appointmentId);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }






        public void DeleteMed(int medicationId)
        {
            try
            {
                OpenConnection();
                string query = "DELETE FROM MedicationTbl WHERE MeddicationId = @MedicationId";
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@MedicationId", medicationId);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }
    }
}
