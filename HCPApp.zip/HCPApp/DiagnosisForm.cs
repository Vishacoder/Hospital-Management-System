﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class DiagnosisForm : Form
    {
        private Functions Con;
        public DiagnosisForm()
        {
            InitializeComponent();
            Con = new Functions();
            ShowDiagnosis();
            ShowMedication();
            ShowPatient();
            ShowDoctor();
        }

        private void ShowDiagnosis()
        {
            try
            {
                string Query = "Select * from DiagnosisTbl";
                DiagnosisList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void ShowMedication()
        {
            try
            {
                string Query = "Select * from MedicationTbl";
                MedicationList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void ShowPatient()
        {
            try
            {
                string Query = "Select * from PatientTbl";
                PatList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void ShowDoctor()
        {
            try
            {
                string Query = "Select * from DoctorTbl";
                DoctList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPatId.Text == "" || txtPatFName.Text == "" || txtPatLName.Text == "" || txtSymp.Text == "" || txtDiag.Text == "" || txtDesc.Text == "" || txtMed.Text == "")
                {
                    MessageBox.Show("Missing Some of Some or All of The data!");
                }
                else
                {
                    string PatId = txtPatId.Text;
                    string PatFName = txtPatFName.Text;
                    string PatLName = txtPatLName.Text;
                    string Symptoms = txtSymp.Text;
                    string Diagnosis = txtDiag.Text;
                    string Description = txtDesc.Text;
                    string Medicine = txtMed.Text;
                    
                    string Query = "INSERT INTO DiagnosisTbl (PatientId, PatientFName, PatientLName, DiagnosisName, Description, Symptoms, MedicationName) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')";
                    Query = string.Format(Query, PatId, PatFName, PatLName, Symptoms, Diagnosis, Description, Medicine); 
                    Con.SetData(Query);
                    ShowPatient();
                    MessageBox.Show("Diagnosis Added.");
                    txtPatId.Text = "";
                    txtPatFName.Text = "";
                    txtPatLName.Text = "";
                    txtSymp.Text = "";
                    txtDiag.Text= "";
                    txtDesc.Text = "";
                    txtMed.Text = "";
                    
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }

        private void DiagnosisList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = DiagnosisList.Rows[e.RowIndex];

                // Fill the text boxes, combo boxes, and DateTimePicker with data from the selected row
                txtPatId.Text = selectedRow.Cells["PatientId"].Value.ToString();
                txtPatFName.Text = selectedRow.Cells["PatientFName"].Value.ToString();
                txtPatLName.Text = selectedRow.Cells["PatientLName"].Value.ToString();
                txtSymp.Text = selectedRow.Cells["Symptoms"].Value.ToString();
                txtDiag.Text = selectedRow.Cells["DiagnosisName"].Value.ToString();
                txtDesc.Text = selectedRow.Cells["Description"].Value.ToString();
                txtMed.Text = selectedRow.Cells["MedicationName"].Value.ToString();
                PatNamelbl.Text = selectedRow.Cells["PatientFName"].Value.ToString() + " " + selectedRow.Cells["PatientLName"].Value.ToString();
                Symplbl.Text = selectedRow.Cells["Symptoms"].Value.ToString();
                Diaglbl.Text = selectedRow.Cells["DiagnosisName"].Value.ToString();
                Desclbl.Text = selectedRow.Cells["Description"].Value.ToString();
                Medlbl.Text = selectedRow.Cells["MedicationName"].Value.ToString();

                


            }
        }
    }
}
