﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace HCPApp
{
    public partial class ReportsForm : Form
    {
        private Functions Con;
        public ReportsForm()
        {
            InitializeComponent(); 
            Con = new Functions();
            ShowMed();
            ShowApp();
        }
        private void ShowMed()
        {
            try
            {
                String Query = "Select * from MedicationTbl";
                MedList.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void ShowApp()
        {
            try
            {
                String Query = "Select * from AppointmentTbl";
                AppList.DataSource = Con.GetData(Query);
            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void ShowPatientCount()
        {
            try
            {
                // Initialize the Functions object
                Con = new Functions();

                // Define the SQL query to get the patient count
                string query = "SELECT COUNT(*) FROM PatientTbl";

                // Execute the query and retrieve the patient count
                int patientCount = (int)Con.ExecuteScalar(query);

                // Display the patient count in the "PatientNo" label
                PatientNo.Text = patientCount.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }









        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            MedicationForm medication = new MedicationForm();
            medication.Show();
            this.Hide();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            AdminDashboard admindashboard = new AdminDashboard();
            admindashboard.Show();
            this.Hide();
        }
        Bitmap bmp;
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int height = MedList.Height;
            MedList.Height = MedList.RowCount * MedList.RowTemplate.Height * 2;
            bmp = new Bitmap(MedList.Width, MedList.Height);
            MedList.DrawToBitmap(bmp, new Rectangle(0, 0, MedList.Width, MedList.Height));
            MedList.Height = height;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font headingFont = new Font("Arial", 24, FontStyle.Bold | FontStyle.Underline);
            Font subheadingFont = new Font("Arial", 18, FontStyle.Bold);
            Font dateFont = new Font("Arial", 12, FontStyle.Italic);
            Font footerFont = new Font("Arial", 10, FontStyle.Bold);
            int pageWidth = e.PageBounds.Width;
            int pageHeight = e.PageBounds.Height;
            int headingY = 50;
            int subheadingY = headingY + headingFont.Height + 10; 
            int dateY = subheadingY + subheadingFont.Height + 10; 
            int dgvY = dateY + dateFont.Height + 30; 
            int footerY = pageHeight - 60; 
            int footer2Y = pageHeight - 40; 

           
            SizeF headingSize = e.Graphics.MeasureString("Health Care Plus", headingFont);
            int headingX = (pageWidth - (int)headingSize.Width) / 2;
            e.Graphics.DrawString("Health Care Plus", headingFont, Brushes.Black, new Point(headingX, headingY));

            
            SizeF subheadingSize = e.Graphics.MeasureString("Medication Report", subheadingFont);
            int subheadingX = (pageWidth - (int)subheadingSize.Width) / 2;
            e.Graphics.DrawString("Medication Report", subheadingFont, Brushes.Black, new Point(subheadingX, subheadingY));
            e.Graphics.DrawLine(new Pen(Brushes.Black), subheadingX, subheadingY + subheadingFont.Height, subheadingX + subheadingSize.Width, subheadingY + subheadingFont.Height);

            
            string todayDate = DateTime.Today.ToString("MMMM dd, yyyy");

           
            e.Graphics.DrawString(todayDate, dateFont, Brushes.Black, new Point(50, dateY));

            
            int dgvHeight = MedList.RowCount * MedList.RowTemplate.Height * 2;

           
            int dgvX = (pageWidth - MedList.Width) / 2;
            e.Graphics.DrawImage(bmp, dgvX, dgvY, MedList.Width, dgvHeight);

            
            SizeF footerSize = e.Graphics.MeasureString("Health Care Plus HSM", footerFont);
            int footerX = (pageWidth - (int)footerSize.Width) / 2;

           
            e.Graphics.DrawString("Health Care Plus HSM", footerFont, Brushes.Black, new Point(footerX, footerY));

           
            SizeF footer2Size = e.Graphics.MeasureString("Powered by Ride Software Solutions", footerFont);
            int footer2X = (pageWidth - (int)footer2Size.Width) / 2;

          
            e.Graphics.DrawString("Powered by Ride Software Solutions", footerFont, Brushes.Black, new Point(footer2X, footer2Y));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();
            appointment.Show();
            this.Hide();

        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font headingFont = new Font("Arial", 24, FontStyle.Bold | FontStyle.Underline);
            Font subheadingFont = new Font("Arial", 18, FontStyle.Bold);
            Font dateFont = new Font("Arial", 12, FontStyle.Italic);
            Font footerFont = new Font("Arial", 10, FontStyle.Bold);
            int pageWidth = e.PageBounds.Width;
            int pageHeight = e.PageBounds.Height;
            int headingY = 50;
            int subheadingY = headingY + headingFont.Height + 10;
            int dateY = subheadingY + subheadingFont.Height + 10;
            int dgvY = dateY + dateFont.Height + 30;
            int footerY = pageHeight - 60;
            int footer2Y = pageHeight - 40;


            SizeF headingSize = e.Graphics.MeasureString("Health Care Plus", headingFont);
            int headingX = (pageWidth - (int)headingSize.Width) / 2;
            e.Graphics.DrawString("Health Care Plus", headingFont, Brushes.Black, new Point(headingX, headingY));


            SizeF subheadingSize = e.Graphics.MeasureString("Medication Report", subheadingFont);
            int subheadingX = (pageWidth - (int)subheadingSize.Width) / 2;
            e.Graphics.DrawString("Medication Report", subheadingFont, Brushes.Black, new Point(subheadingX, subheadingY));
            e.Graphics.DrawLine(new Pen(Brushes.Black), subheadingX, subheadingY + subheadingFont.Height, subheadingX + subheadingSize.Width, subheadingY + subheadingFont.Height);


            string todayDate = DateTime.Today.ToString("MMMM dd, yyyy");


            e.Graphics.DrawString(todayDate, dateFont, Brushes.Black, new Point(50, dateY));


            int dgvHeight = MedList.RowCount * MedList.RowTemplate.Height * 2;


            int dgvX = (pageWidth - MedList.Width) / 2;
            e.Graphics.DrawImage(bmp, dgvX, dgvY, MedList.Width, dgvHeight);


            SizeF footerSize = e.Graphics.MeasureString("Health Care Plus HSM", footerFont);
            int footerX = (pageWidth - (int)footerSize.Width) / 2;


            e.Graphics.DrawString("Health Care Plus HSM", footerFont, Brushes.Black, new Point(footerX, footerY));


            SizeF footer2Size = e.Graphics.MeasureString("Powered by Ride Software Solutions", footerFont);
            int footer2X = (pageWidth - (int)footer2Size.Width) / 2;


            e.Graphics.DrawString("Powered by Ride Software Solutions", footerFont, Brushes.Black, new Point(footer2X, footer2Y));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int height = AppList.Height;
            AppList.Height = AppList.RowCount * AppList.RowTemplate.Height * 2;
            bmp = new Bitmap(AppList.Width, AppList.Height);
            AppList.DrawToBitmap(bmp, new Rectangle(0, 0, AppList.Width, AppList.Height));
            AppList.Height = height;
            printPreviewDialog1.ShowDialog();
        }
    }
}
