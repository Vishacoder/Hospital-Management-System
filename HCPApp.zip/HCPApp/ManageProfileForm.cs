﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCPApp
{
    public partial class ManageProfileForm : Form
    {
        StaffClass Con;
        private string staffMemberName;
        public ManageProfileForm(string staffMemberName)
        {
            InitializeComponent();
            Con = new StaffClass();
            this.staffMemberName = staffMemberName;
            LoadUserProfile();
        }
        private void GoBackToStaffDashboard()
        {
            this.Close();
            StaffDashboard staffDashboard = new StaffDashboard(staffMemberName);
            staffDashboard.Show();
        }
        private void LoadUserProfile()
        {
           
            string[] userInfo = Con.GetUserProfileInformation(staffMemberName);

            
            if (userInfo != null && userInfo.Length >= 3)
            {
                txtFirstName.Text = userInfo[0];
                txtLastName.Text = userInfo[1];
                txtEmail.Text = userInfo[2];
            }
            else
            {
               
                MessageBox.Show("Failed to retrieve user information.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GoBackToStaffDashboard();
        }
    }
}
