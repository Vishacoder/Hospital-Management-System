﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Drawing.Printing;


namespace HCPApp
{
    public partial class StaffAppointment : Form
    {

        StaffFunction Con;
        private string staffMemberName;
        public StaffAppointment(string staffMemberName)
        {
            InitializeComponent();
            Con = new StaffFunction();
            this.staffMemberName = staffMemberName;
            ShowDoctors();
            ShowPatient();
            ShowAppointment();
            ComboSSpec.SelectedIndexChanged += new EventHandler(ComboSSpec_SelectedIndexChanged);
        }

        private void GoBackToStaffDashboard()
        {
            this.Close();
            StaffDashboard staffDashboard = new StaffDashboard(staffMemberName);
            staffDashboard.Show();
        }
        private void ShowDoctors()
        {
            try
            {
                string Query = "Select * from DoctorTbl";
                DocData.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void ShowPatient()
        {
            try
            {
                string Query = "Select * from PatientTbl";
                PatData.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void ShowAppointment()
        {
            try
            {
                string Query = "Select * from AppointmentTbl";
                AppointmentData.DataSource = Con.GetData(Query);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StaffPatient staffpatient = new StaffPatient(staffMemberName);
            staffpatient.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            StaffDoctor staffdoctor = new StaffDoctor(staffMemberName);
            staffdoctor.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            StaffAppointment staffappointmentform = new StaffAppointment(staffMemberName);
            staffappointmentform.Show();
            this.Hide();
        }
        private void ComboSSpec_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSpec = ComboSSpec.SelectedItem.ToString();

            DataView dv = new DataView(Con.GetData("Select * from DoctorTbl"));
            dv.RowFilter = $"Specification = '{selectedSpec}'";

            DocData.DataSource = dv;
        }
        private void txtSPatient_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string patientFirstName = txtSPatient.Text.Trim();
                string query;

                if (string.IsNullOrEmpty(patientFirstName))
                {
                    // If the TextBox is empty, show all patients
                    query = "SELECT * FROM PatientTbl";
                }
                else
                {
                    // If there's text in the TextBox, filter by first name
                    query = "SELECT * FROM PatientTbl WHERE FirstName LIKE @FirstName";
                }

                DataTable dt = Con.GetData(query);

                if (!string.IsNullOrEmpty(patientFirstName))
                {
                    // If there's text, add a parameter for filtering
                    dt.DefaultView.RowFilter = $"FirstName LIKE '%{patientFirstName}%'";
                }
                else
                {
                    dt.DefaultView.RowFilter = string.Empty;
                }

                PatData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtSPatient_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                string patientFirstName = txtSPatient.Text.Trim();

                DataView dv = new DataView(Con.GetData("SELECT * FROM PatientTbl"));

                if (!string.IsNullOrEmpty(patientFirstName))
                {
                    // If there's text, filter by first name
                    dv.RowFilter = $"FirstName LIKE '%{patientFirstName}%'";
                }
                else
                {
                    // If the TextBox is empty, show all patients
                    dv.RowFilter = string.Empty;
                }

                PatData.DataSource = dv;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the values from your form's controls
                int patientId = int.Parse(txtPatId.Text);
                string patFName = txtPatFName.Text;
                string patLName = txtPatLName.Text;
                int doctorId = int.Parse(txtDocId.Text);
                string docFName = txtDocFName.Text;
                string docLName = txtDocLName.Text;
                DateTime appointmentDate = DoBPicker.Value;
                string appointmentTime = ComboTime.SelectedItem.ToString();
                int appointmentNumber = Con.GetNextAppointmentNumber();
                decimal charge = decimal.Parse(txtCharge.Text);
               
               
                // Call the AddAppointment method to insert data
                Con.AddAppointment(patientId, patFName, patLName, doctorId, docFName, docLName, appointmentDate, appointmentTime, appointmentNumber, charge);

                // Show a success message or perform other actions as needed
                MessageBox.Show("Appointment added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void DocData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow selectedRow = DocData.Rows[e.RowIndex];

               
                txtDocId.Text = selectedRow.Cells["DoctorId"].Value.ToString();
                txtDocFName.Text = selectedRow.Cells["FirstName"].Value.ToString();
                txtDocLName.Text = selectedRow.Cells["LastName"].Value.ToString();
            }
        }

        private void PatData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow selectedRow = PatData.Rows[e.RowIndex];

                txtPatId.Text = selectedRow.Cells["PatientId"].Value.ToString();
                txtPatFName.Text = selectedRow.Cells["FirstName"].Value.ToString();
                txtPatLName.Text = selectedRow.Cells["LastName"].Value.ToString();
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AppointmentData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow selectedRow = AppointmentData.Rows[e.RowIndex];

                // Fill the text boxes, combo boxes, and DateTimePicker with data from the selected row
                txtPatId.Text = selectedRow.Cells["PatientId"].Value.ToString();
                txtPatFName.Text = selectedRow.Cells["PatFName"].Value.ToString();
                txtPatLName.Text = selectedRow.Cells["PatLName"].Value.ToString();
                txtDocId.Text = selectedRow.Cells["DoctorId"].Value.ToString();
                txtDocFName.Text = selectedRow.Cells["DocFName"].Value.ToString();
                txtDocLName.Text = selectedRow.Cells["DocLName"].Value.ToString();
                DoBPicker.Value = (DateTime)selectedRow.Cells["AppointmentDate"].Value;
                ComboTime.SelectedItem = selectedRow.Cells["AppointmentTime"].Value.ToString();
                txtCharge.Text = selectedRow.Cells["Charge"].Value.ToString();
                PatNamelbl.Text = selectedRow.Cells["PatFName"].Value.ToString() + " " + selectedRow.Cells["PatLName"].Value.ToString();
                DocNamelbl.Text = selectedRow.Cells["DocFName"].Value.ToString() + " " + selectedRow.Cells["DocLName"].Value.ToString();
                AppDatelbl.Text = ((DateTime)selectedRow.Cells["AppointmentDate"].Value).ToString("yyyy-MM-dd");
                Timelbl.Text = selectedRow.Cells["AppointmentTime"].Value.ToString();
                Chargelbl.Text = selectedRow.Cells["Charge"].Value.ToString();



            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the values from your form's controls
                int patientId = int.Parse(txtPatId.Text);
                string patFName = txtPatFName.Text;
                string patLName = txtPatLName.Text;
                int doctorId = int.Parse(txtDocId.Text);
                string docFName = txtDocFName.Text;
                string docLName = txtDocLName.Text;
                DateTime appointmentDate = DoBPicker.Value;
                string appointmentTime = ComboTime.SelectedItem.ToString();
                decimal charge = decimal.Parse(txtCharge.Text);

                // Call the UpdateAppointment method to update the record
                Con.UpdateAppointment(patientId, patFName, patLName, doctorId, docFName, docLName, appointmentDate, appointmentTime, charge);

                // Show a success message
                MessageBox.Show("Appointment updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if a row is selected
                if (AppointmentData.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = AppointmentData.SelectedRows[0];

                    // Get the appointment information from the selected row
                    int appointmentId = int.Parse(selectedRow.Cells["AppointmentId"].Value.ToString());

                    // Confirm the deletion with a message box
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this appointment?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        // Call the method in your StaffFunction class to delete the appointment
                        Con.DeleteAppointment(appointmentId);

                        // Show a success message
                        MessageBox.Show("Appointment deleted successfully.");

                        // Refresh the DataGridView to reflect the changes
                        ShowAppointment();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            GoBackToStaffDashboard();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click_1(object sender, EventArgs e)
        {
            GoBackToStaffDashboard();
        }

        private void StaffAppointment_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hCPAppDBDataSet3.RoomsTbl' table. You can move, or remove it, as needed.
            this.roomsTblTableAdapter2.Fill(this.hCPAppDBDataSet3.RoomsTbl);

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Create a Graphics object to draw on the page
            Graphics graphics = e.Graphics;

            // Define your page settings
            float leftMargin = 50; // Adjust as needed
            float topMargin = 50; // Adjust as needed
            float pageWidth = e.PageBounds.Width - leftMargin * 2;

            // Define fonts and styles
            Font titleFont = new Font("Arial", 20, FontStyle.Bold | FontStyle.Italic);
            Font boldFont = new Font("Arial", 12, FontStyle.Bold);
            Font regularFont = new Font("Arial", 12);

            // Draw the hospital name
            string hospitalName = "Health Care Plus";
            SizeF hospitalNameSize = graphics.MeasureString(hospitalName, titleFont);
            float x = leftMargin + (pageWidth - hospitalNameSize.Width) / 2;
            PointF titlePosition = new PointF(x, topMargin);
            graphics.DrawString(hospitalName, titleFont, Brushes.Black, titlePosition);

            // Draw email
            string emailLabel = "Email:";
            string email = "Vishwaanupama12@gmail.com";
            float emailY = topMargin + hospitalNameSize.Height + 20; // Adjust the vertical position
            graphics.DrawString(emailLabel, boldFont, Brushes.Black, leftMargin, emailY);
            graphics.DrawString(email, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(emailLabel, boldFont).Width + 10, emailY);

            // Draw phone number
            string phoneLabel = "Phone:";
            string phoneNumber = "077 654 1091"; // Replace with the actual phone number
            float phoneY = emailY + regularFont.Height + 10; // Adjust the vertical position
            graphics.DrawString(phoneLabel, boldFont, Brushes.Black, leftMargin, phoneY);
            graphics.DrawString(phoneNumber, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(phoneLabel, boldFont).Width + 10, phoneY);

            // Draw address
            string addressLabel = "Address:";
            string address = "194/A East Halpanwila Marawila"; // Replace with the actual address
            float addressY = phoneY + regularFont.Height + 10; // Adjust the vertical position
            graphics.DrawString(addressLabel, boldFont, Brushes.Black, leftMargin, addressY);
            graphics.DrawString(address, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(addressLabel, boldFont).Width + 10, addressY);

            // Draw a line below the hospital name
            float lineY = topMargin + hospitalNameSize.Height + 10; // Adjust the vertical position
            graphics.DrawLine(Pens.Black, leftMargin, lineY, leftMargin + pageWidth, lineY);

            // Draw a line after the address
            float lineAfterAddressY = addressY + regularFont.Height + 10; // Adjust the vertical position
            graphics.DrawLine(Pens.Black, leftMargin, lineAfterAddressY, leftMargin + pageWidth, lineAfterAddressY);

            // Draw the "Appointment Receipt" title
            Font receiptTitleFont = new Font("Arial", 16, FontStyle.Bold | FontStyle.Underline);
            string receiptTitle = "Appointment Receipt";
            SizeF receiptTitleSize = graphics.MeasureString(receiptTitle, receiptTitleFont);
            float receiptX = leftMargin + (pageWidth - receiptTitleSize.Width) / 2;
            float receiptY = lineAfterAddressY + 20; // Adjust the vertical position
            PointF receiptTitlePosition = new PointF(receiptX, receiptY);
            graphics.DrawString(receiptTitle, receiptTitleFont, Brushes.Black, receiptTitlePosition);

            // Draw patient name
            string patientNameLabel = "Patient Name:";
            string patientName = PatNamelbl.Text; // Use the label's text
            float patientNameY = receiptY + receiptTitleSize.Height + 10; // Adjust the vertical position
            graphics.DrawString(patientNameLabel, boldFont, Brushes.Black, leftMargin, patientNameY);
            graphics.DrawString(patientName, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(patientNameLabel, boldFont).Width + 10, patientNameY);

            // Draw doctor name
            string doctorNameLabel = "Doctor Name:";
            string doctorName = DocNamelbl.Text; // Use the label's text
            float doctorNameY = patientNameY + receiptTitleSize.Height + 10; // Adjust the vertical position
            graphics.DrawString(doctorNameLabel, boldFont, Brushes.Black, leftMargin, doctorNameY);
            graphics.DrawString(doctorName, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(doctorNameLabel, boldFont).Width + 10, doctorNameY);

            // Draw Appointment Date
            string appointmentdateLabel = "Appointment Date:";
            string appointmentdate = AppDatelbl.Text; // Use the label's text
            float appointmentdateY = doctorNameY + receiptTitleSize.Height + 10; // Adjust the vertical position
            graphics.DrawString(appointmentdateLabel, boldFont, Brushes.Black, leftMargin, appointmentdateY);
            graphics.DrawString(appointmentdate, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(appointmentdateLabel, boldFont).Width + 10, appointmentdateY);

            // Draw Appointment Time name
            string appointmenttimeLabel = "Appointment Time:";
            string appointmenttime = Timelbl.Text; // Use the label's text
            float appointmenttimeY = appointmentdateY + receiptTitleSize.Height + 10; // Adjust the vertical position
            graphics.DrawString(appointmenttimeLabel, boldFont, Brushes.Black, leftMargin, appointmenttimeY);
            graphics.DrawString(appointmenttime, regularFont, Brushes.Black, leftMargin + graphics.MeasureString(appointmenttimeLabel, boldFont).Width + 10, appointmenttimeY);

            // ... Previous code ...

            // Calculate the total charge
            decimal charge = decimal.Parse(Chargelbl.Text); // Convert the label's text to decimal
            decimal extraCharge = 50.0m; // Replace with the actual extra charge value
            decimal totalCharge = charge + extraCharge;

            // Draw charge on the right side of the page under "Appointment Time"
            string chargeLabel = "Doctor Charge:";
            string chargeValue = charge.ToString("C"); // Format the charge as currency
            float chargeLabelWidth = graphics.MeasureString(chargeLabel, boldFont).Width;
            float chargeValueX = leftMargin + pageWidth - chargeLabelWidth - 100; // Adjust the X position
            float chargeY = appointmenttimeY + receiptTitleSize.Height + 10; // Same vertical position as the appointment time
            graphics.DrawString(chargeLabel, boldFont, Brushes.Black, chargeValueX, chargeY);
            graphics.DrawString(chargeValue.Replace("£", "LKR"), regularFont, Brushes.Black, chargeValueX + chargeLabelWidth + 10, chargeY);

            // Draw Hospital Charge
            string hospitalChargeLabel = "Hospital Charge:";
            decimal hospitalChargeValue = 500.0m; // Replace with the actual hospital charge value
            string hospitalChargeValueText = hospitalChargeValue.ToString("C"); // Format the hospital charge as currency
            float hospitalChargeLabelWidth = graphics.MeasureString(hospitalChargeLabel, boldFont).Width;
            float hospitalChargeValueX = leftMargin + pageWidth - hospitalChargeLabelWidth - 100; // Adjust the X position
            float hospitalChargeY = chargeY + regularFont.Height + 10; // Adjust the vertical position
            graphics.DrawString(hospitalChargeLabel, boldFont, Brushes.Black, hospitalChargeValueX, hospitalChargeY);
            graphics.DrawString(hospitalChargeValueText.Replace("£","LKR"), regularFont, Brushes.Black, hospitalChargeValueX + hospitalChargeLabelWidth + 10, hospitalChargeY);

            // Draw a horizontal line under Hospital Charge
            float lineUnderHospitalChargeY = hospitalChargeY + regularFont.Height + 10; // Adjust the vertical position
            graphics.DrawLine(Pens.Black, hospitalChargeValueX, lineUnderHospitalChargeY, leftMargin + pageWidth, lineUnderHospitalChargeY);

            // Draw Total
            string totalLabel = "Total:";
            decimal totalValue = totalCharge + hospitalChargeValue; // Calculate the total
            string totalValueText = totalValue.ToString("C"); // Format the total as currency
            float totalLabelWidth = graphics.MeasureString(totalLabel, boldFont).Width;
            float totalValueX = leftMargin + pageWidth - totalLabelWidth - 100; // Adjust the X position
            float totalY = lineUnderHospitalChargeY + 10; // Adjust the vertical position
            graphics.DrawString(totalLabel, boldFont, Brushes.Black, totalValueX, totalY);
            graphics.DrawString(totalValueText.Replace("£", "LKR"), regularFont, Brushes.Black, totalValueX + totalLabelWidth + 10, totalY);

            // Draw two lines under "Total"
            float line1Y = totalY + regularFont.Height + 5; // Adjust the vertical position for the first line
            float line2Y = line1Y + 5; // Adjust the vertical position for the second line
            graphics.DrawLine(Pens.Black, totalValueX, line1Y, leftMargin + pageWidth, line1Y);
            graphics.DrawLine(Pens.Black, totalValueX, line2Y, leftMargin + pageWidth, line2Y);

            // Indicate that there are no more pages to print
            e.HasMorePages = false;

            // Add text at the bottom center of the page
            string bottomText1 = "Health Care Plus HMS";
            string bottomText2 = "Powered By Ride Software Solutions";

            // Define fonts and colors for the bottom text
            Font bottomFont1 = new Font("Arial", 12);
            Font bottomFont2 = new Font("Arial", 10);
            Brush bottomBrush1 = Brushes.Brown;
            Brush bottomBrush2 = Brushes.Black; // You can change the color as needed

            // Calculate the width and height of the page
            float PageWidth = e.PageBounds.Width;
            float pageHeight = e.PageBounds.Height;

            // Calculate the size of the bottom text
            SizeF textSize1 = e.Graphics.MeasureString(bottomText1, bottomFont1);
            SizeF textSize2 = e.Graphics.MeasureString(bottomText2, bottomFont2);

            // Calculate the X and Y positions for centering the text at the bottom
            float textX1 = (PageWidth - textSize1.Width) / 2;
            float textX2 = (PageWidth - textSize2.Width) / 2;
            float textY1 = pageHeight - textSize1.Height - 30; // 10 is the margin from the bottom
            float textY2 = textY1 + textSize1.Height + 2; // Some vertical spacing between the two lines

            // Draw the bottom text
            e.Graphics.DrawString(bottomText1, bottomFont1, bottomBrush1, textX1, textY1);
            e.Graphics.DrawString(bottomText2, bottomFont2, bottomBrush2, textX2, textY2);
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            // Create a PrintDocument instance
            PrintDocument printDocument = new PrintDocument();

            // Add an event handler for the PrintPage event
            printDocument.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }
    }

}
