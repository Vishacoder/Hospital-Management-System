﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace HCPApp
{
    class StaffFunction
    {
        private SqlConnection Con;
        private SqlCommand cmd;
        private DataTable dt;
        private SqlDataAdapter sda;
        private string Constr;


        public StaffFunction()
        {
            Constr = @"Data Source=LAPTOP-A9K7TF0H\SQLEXPRESS;Initial Catalog=HCPAppDB;Integrated Security=True";
            Con = new SqlConnection(Constr);
            cmd = new SqlCommand();
            cmd.Connection = Con;
        }

        public void OpenConnection()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        public void CloseConnection()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }


        public DataTable GetData(string query)
        {
            DataTable dt = new DataTable();
            try
            {
                OpenConnection();
                cmd.CommandText = query;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
            return dt;
        }
        public void AddAppointment(int patientId, string patFName, string patLName, int doctorId, string docFName, string docLName, DateTime appointmentDate, string appointmentTime, int appointmentNumber, decimal charge)
        {
            try
            {
                Con.Open();
                string query = "INSERT INTO AppointmentTbl (PatientId, PatFName, PatLName, DoctorId, DocFName, DocLName, AppointmentDate, AppointmentTime, AppointmentNumber, Charge) " +
                               "VALUES (@PatientId, @PatFName, @PatLName, @DoctorId, @DocFName, @DocLName, @AppointmentDate,@AppointmentTime, @AppointmentNumber, @Charge)";
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@PatientId", patientId);
                cmd.Parameters.AddWithValue("@PatFName", patFName);
                cmd.Parameters.AddWithValue("@PatLName", patLName);
                cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                cmd.Parameters.AddWithValue("@DocFName", docFName);
                cmd.Parameters.AddWithValue("@DocLName", docLName);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                cmd.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                cmd.Parameters.AddWithValue("@AppointmentNumber", appointmentNumber);
                cmd.Parameters.AddWithValue("@Charge", charge);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Con.Close();
            }
        }

        public int GetNextAppointmentNumber()
        {
            try
            {
                OpenConnection();
                string query = "SELECT ISNULL(MAX(AppointmentNumber), 0) + 1 FROM AppointmentTbl";
                cmd.CommandText = query;
                int nextAppointmentNumber = (int)cmd.ExecuteScalar();
                return nextAppointmentNumber;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        public void UpdateAppointment(int patientId, string patFName, string patLName, int doctorId, string docFName, string docLName, DateTime appointmentDate, string appointmentTime, decimal charge)
        {
            try
            {
                OpenConnection();
                string query = "UPDATE AppointmentTbl " +
                               "SET PatFName = @PatFName, PatLName = @PatLName, " +
                               "DoctorId = @DoctorId, DocFName = @DocFName, " +
                               "DocLName = @DocLName, AppointmentDate = @AppointmentDate, " +
                               "AppointmentTime = @AppointmentTime, Charge = @Charge " +
                               "WHERE PatientId = @PatientId";

                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@PatientId", patientId);
                cmd.Parameters.AddWithValue("@PatFName", patFName);
                cmd.Parameters.AddWithValue("@PatLName", patLName);
                cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                cmd.Parameters.AddWithValue("@DocFName", docFName);
                cmd.Parameters.AddWithValue("@DocLName", docLName);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                cmd.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                cmd.Parameters.AddWithValue("@Charge", charge);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        public void DeleteAppointment(int appointmentId)
        {
            try
            {
                OpenConnection();
                string query = "DELETE FROM AppointmentTbl WHERE AppointmentId = @AppointmentId";
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@AppointmentId", appointmentId);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }




        //***************************patient****************************

        public int UpdatePatientInfo(int patientId, string firstName, string lastName, DateTime dob, string gender, string bloodGroup, string contact, string medicalHistory, string allergies, string connectionString)
        {
            string query = "UPDATE PatientTbl SET FirstName = @FirstName, LastName = @LastName, DoB = @DoB, Gender = @Gender, BloodGroup = @BloodGroup, PatientContact = @PatientContact, MedicalHistory = @MedicalHistory, Allergies = @Allergies WHERE PatientId = @PatientId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@DoB", dob);
                command.Parameters.AddWithValue("@Gender", gender);
                command.Parameters.AddWithValue("@BloodGroup", bloodGroup);
                command.Parameters.AddWithValue("@PatientContact", contact);
                command.Parameters.AddWithValue("@MedicalHistory", medicalHistory);
                command.Parameters.AddWithValue("@Allergies", allergies);
                command.Parameters.AddWithValue("@PatientId", patientId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }
        }
        public int DeletePatient(int patientId, string connectionString)
        {
            string query = "DELETE FROM PatientTbl WHERE PatientId = @PatientId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();

                command.Parameters.AddWithValue("@PatientId", patientId);

                int rowsAffected = command.ExecuteNonQuery();

                connection.Close();

                return rowsAffected;
            }
        }

        public int GetRoomIdByRoomName(string roomName)
        {
            int roomId = -1;

            string query = "SELECT RoomId FROM RoomsTbl WHERE RoomName = @RoomName";

            using (SqlConnection connection = new SqlConnection(Constr))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@RoomName", roomName);

                object result = command.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {
                    roomId = Convert.ToInt32(result);
                }
            }

            return roomId;
        }

    }
}



