﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCPApp
{
    public static class UserManager
    {
        public static string CurrentUsername { get; private set; }

        public static void SetCurrentUser(string username)
        {
            CurrentUsername = username;
        }
    }
}
